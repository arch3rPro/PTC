$var1 = 1;
$var2 = 1336;
echo $var1+$var2;